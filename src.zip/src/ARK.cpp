#include "ARK.h"

int main(int, char**)
{
    Game ARK;

    ARK.startGameLoop();



    return 0;
}